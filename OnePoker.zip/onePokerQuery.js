$(function(){
    // history.pushState(null, null, location.href); //ブラウザバック無効化
    // //ブラウザバックボタン押下時
    // $(window).on("popstate", function () {
    //     history.go(1);
    // });

    $('#pl1_up1,#pl1_down1,#pl1_up2,#pl1_down2,#pl2_up1,#pl2_down1,#pl2_up2,#pl2_down2').hide().fadeIn(2500);

});