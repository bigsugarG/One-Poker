$(function() {
    $('#text,#subtext').hide().fadeIn(4444);
});

